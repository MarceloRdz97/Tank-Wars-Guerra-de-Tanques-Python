import matplotlib.pyplot as graph
import numpy as np
import math as m
import random as r
import time as t
import pandas as pd

def shoot(pos, pos2, t, v, theta, player):
    #pos = [x cordinate, y cordinate] of shooter
    theta = theta * (3.141/180)

    xshot = []
    yshot =[]
    for i in range(len(t)): 
        xshot.append(t[i] * v * m.cos(theta) + pos[0])
        yshot.append(-9.81 * (t[i]**2) * 0.5 + v * m.sin(theta) * t[i] + pos[1])
        
    for i in range(len(t)):
        if round(xshot[i],1) == round(pos2[0],1) and round(yshot[i],1) == round(pos2[1],1):
            print("HIT! ", player," wins.")     
    graph.plot(xshot,yshot,"--y")
    graph.show()
    return None

print("TANK WARS")
print("(1) SHOOT P1")
print("(2) SHOOT P2")
print("(3) NEW GAME")
option = input()

resolution = 1000
t = np.linspace(0,10,resolution)

if option == "3":
    
    a = r.uniform(0.2,0.8) # Altura
    b = r.uniform(1,2) #Alargamiento

    #Se grafica el suelo (x) respecto a t
    floor = []

    for i in range(len(t)):
        floor.append(a * m.cos(b * t[i])) #funcion coseno del piso
        
    graph.axis([0, 10, -1.5 , 5]) # delimitacion
    graph.plot(t,floor, "g")


    p1PositionIdx = r.randint(1,resolution * 0.4) #indice de la posicion random que este en el primer 40% de la grafica
    p1 = [t[p1PositionIdx],floor[p1PositionIdx]] #se asigna la posicion del punto del jugador
    graph.plot(p1[0],p1[1],'ro')

    p2PositionIdx = r.randint(resolution * 0.6,resolution -1) #indice de la posicion random que este despues del 60% de la grafica
    p2 = [t[p2PositionIdx],floor[p2PositionIdx]] #se asigna la posicion del punto del jugador
    graph.plot(p2[0],p2[1],'bo')

    graph.show()
    
    data = {
    'p1': p1,
    'p2': p2
    }
    df = pd.DataFrame(data)
    excel_file = 'Cords.xlsx'
    sheet_name = 'Sheet1'
    df.to_excel(excel_file, sheet_name=sheet_name, index=False)

    
    floor = {
    'floor': floor
    }
    df = pd.DataFrame(floor)
    excel_file = 'Floor.xlsx'
    sheet_name = 'Sheet1'
    df.to_excel(excel_file, sheet_name=sheet_name, index=False)
    
if option == "1":
    
    v = float(input("Force: "))
    theta = float(input("Angle: "))
    cords = pd.read_excel("Cords.xlsx")
    pos = cords["p1"]
    pos2 = cords["p2"]
    ground = pd.read_excel("Floor.xlsx")
    floor = ground["floor"]
    player = "P1"
    
    graph.axis([0, 10, -1.5 , 5]) # delimitacion
    graph.plot(t,floor, "g")
    
    graph.plot(pos[0],pos[1],'ro')
    graph.plot(pos2[0],pos2[1],'bo')
    
    shoot(pos, pos2, t, v, theta, player)
    
if option == "2":
    
    v = - float(input("Force: "))
    theta = 3.141 - float(input("Angle: ")) 
    cords = pd.read_excel("Cords.xlsx")
    pos = cords["p2"]
    pos2 = cords["p1"]
    ground = pd.read_excel("Floor.xlsx")
    floor = ground["floor"]
    player = "P2"
    
    graph.axis([0, 10, -1.5 , 5]) # delimitacion
    graph.plot(t,floor, "g")
    
    graph.plot(pos[0],pos[1],'ro')
    graph.plot(pos2[0],pos2[1],'bo')
    
    shoot(pos, pos2, t, v, theta, player)
    
